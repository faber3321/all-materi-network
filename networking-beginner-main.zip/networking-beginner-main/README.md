# networking-beginner
belajar network untuk beginner
